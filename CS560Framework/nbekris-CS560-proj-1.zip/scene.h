////////////////////////////////////////////////////////////////////////
// The scene class contains all the parameters needed to define and
// draw a simple scene, including:
//   * Geometry
//   * Light parameters
//   * Material properties
//   * Viewport size parameters
//   * Viewing transformation values
//   * others ...
//
// Some of these parameters are set when the scene is built, and
// others are set by the framework in response to user mouse/keyboard
// interactions.  All of them can be used to draw the scene.

#include "shapes.h"
#include "texture.h"
#include "fbo.h"
#include "gbuffer.h"
#include "Mesh.h"
#include "WireframeFloor.h"
#include <array>
#include <memory>

class Shader;


class Scene
{
public:
    GLFWwindow* window;

    // Light parameters
    float lightSpin, lightTilt, lightDist;
    glm::vec3 lightPos = {-30.0f, -60.f, 90.0f};
    glm::vec3 lightCol = {1.0f, 1.0f, 1.0f};
    glm::vec3 lightDir = {1.0f, -1.0f, -1.0f};

    //buffer
    GBuffer gBuffer;
    unsigned int id, bindpoint;

    double previousFrameTime = 0.0;

    int key;
    float spin, tilt, speed, ry, front, back;
    glm::vec3 eye;
    glm::vec3 tr;
    double last_time;
    int mode; 

    
    // Viewport
    int width, height;

    // Transformations
    glm::mat4 WorldProj, WorldView, WorldInverse;
    glm::mat4 lightProj, lightView;

    // Non-owning pointer to the active cached model.
    Mesh* model = nullptr;
    std::array<std::unique_ptr<Mesh>, 2> loadedModels;
    Shape* quad; //deferred shading
    WireframeFloor floor;

    //UI
    bool bone = true;
    bool mesh = false;
    int selectedAnimationPreset = 0;
    int selectedModel = 0;
    std::string modelLoadError;

    // Shader programs
    ShaderProgram* lightingProgram;
    ShaderProgram* gBufferProgram;
    ShaderProgram* basicShader;

    void InitCamera();
    void CreateQuad();
    void DrawQuad();
    void InitializeScene();
    bool SelectModel(int index);
    void ReleaseModels();
    void BuildTransforms();
    void DrawMenu();
    void DrawScene();

};
